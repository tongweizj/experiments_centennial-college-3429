import express from 'express';
import cookieSession from 'cookie-session';
import bodyParser from 'body-parser';
import { initStorage, getUser, setUser } from './storage';
import crypto from 'crypto';
import util from 'util';
import qrcode from 'qrcode';
import base32Encode from 'base32-encode';
import { verifyTOTP } from './otp';
 
initStorage();
 
const app = express();
 
app.use(
  cookieSession({
    secret: 'mysecret',
  })
);
 
app.use(bodyParser.json());
 
app.use(express.static('build/public'));
 
// Restore user from session
app.use(function (req, res, next) {
  if (req.session.username) {
    req.user = getUser(req.session.username);
  }
  next();
});
 
app.get('/logout', (req, res) => {
  req.session = null;
  res.redirect('/');
});
 
app.post('/login', (req, res) => {
  let authenticatedUser;
 
  const { body } = req;
