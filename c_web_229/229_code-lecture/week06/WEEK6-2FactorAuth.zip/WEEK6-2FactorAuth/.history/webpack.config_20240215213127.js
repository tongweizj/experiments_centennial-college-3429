const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
 
const commonConfig = {
  mode: 'development',
 
  module: {
    rules: [
      {
        test: /\.m?js$/,
        exclude: /node_modules/,
        use: {
            loader: 'babel-loader',
            options: {
              babelrc: false,
              configFile: false,
              presets: [
                ['@babel/preset-env', { targets: { esmodules: true } }],
                '@babel/preset-react',
              ],
            },
            