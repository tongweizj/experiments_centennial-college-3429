export async function login(username, password) {
    const res = await fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
  
    export async function verifyOtp(code) {
        const res = await fetch('/verify_otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code }),
        });
      
        return res.json();
      }
      

    if (res.status === 401) return {};
  

    const user = await res.json();
  

    return { user };
  }

