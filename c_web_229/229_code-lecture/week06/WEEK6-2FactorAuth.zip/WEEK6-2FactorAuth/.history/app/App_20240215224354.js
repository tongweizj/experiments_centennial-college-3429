import React from 'react';
import Login from './Login';
import OneTimePassword from './OneTimePassword';
 
export default function App({ user, requireMfa }) {
  // User enabled MFA but did not verify code, show OTP form
  if (requireMfa) {
    return <OneTimePassword enabled={true} />;
  }
 
  